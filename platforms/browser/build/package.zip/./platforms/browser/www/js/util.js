function EnterTab(InputId, Evento) {
    if (Evento.keyCode == 13) {
        document.getElementById(InputId).focus();
    }
}

//remove a mascara moeda do valor
function removeMascara(valor) {
    valor = valor.replace(".", "");
    valor = valor.replace(",", ".");
    return parseFloat(valor);
}

function numberToReal(num) {
    var numero = parseFloat(num);
    var numero = numero.toFixed(2).split('.');
    numero[0] = numero[0].split(/(?=(?:...)*$)/).join('.');
    return numero.join(',');
}

//formata de forma generica os campos
function formataCampo(campo, Mascara, evento) {
    var boleanoMascara;

    var Digitato = evento.keyCode;
    exp = /\-|\.|\/|\(|\)| /g
    campoSoNumeros = campo.value.toString().replace(exp, "");

    var posicaoCampo = 0;
    var NovoValorCampo = "";
    var TamanhoMascara = campoSoNumeros.length;
    ;

    if (Digitato != 8) { // backspace
        for (i = 0; i <= TamanhoMascara; i++) {
            boleanoMascara = ((Mascara.charAt(i) == "-") || (Mascara.charAt(i) == ".")
                || (Mascara.charAt(i) == "/"))
            boleanoMascara = boleanoMascara || ((Mascara.charAt(i) == "(")
                || (Mascara.charAt(i) == ")") || (Mascara.charAt(i) == " "))
            if (boleanoMascara) {
                NovoValorCampo += Mascara.charAt(i);
                TamanhoMascara++;
            } else {
                NovoValorCampo += campoSoNumeros.charAt(posicaoCampo);
                posicaoCampo++;
            }
        }
        campo.value = NovoValorCampo;
        return true;
    } else {
        return true;
    }
}
function verificaNovoEmail(email) {
    if (email.indexOf("@") < 0 || email.indexOf(".com") < 0) {
        Materialize.toast('E-MAIL INVALIDO', 4000);
        return false;
    }
    return true;
}