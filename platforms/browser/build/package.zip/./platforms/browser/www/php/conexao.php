<?php
$con = mysqli_connect("localhost", "id2990907_root", "fera123fera", "id2990907_lessa");
if (!$con) {
    die('Erro ao conectar ao banco: ' . mysql_error());
}

?>